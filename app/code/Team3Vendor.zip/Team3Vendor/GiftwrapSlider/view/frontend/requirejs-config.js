var config = {
    paths: {            
            'owl-carousel': "Team3Vendor_GiftwrapSlider/js/owl.carousel.min"
    },   
    shim: {
        'owl-carousel': {
            deps: ['jquery']
        }
    }
};
