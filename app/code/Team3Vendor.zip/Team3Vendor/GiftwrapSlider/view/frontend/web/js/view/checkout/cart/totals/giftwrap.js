define(
    [
       'Team3Vendor_GiftwrapSlider/js/view/checkout/summary/giftwrap-fee'
],
function (Component) {
    'use strict';
    return Component.extend({
        /**
         * @override
         */
        isDisplayed: function () {
            return true;
        }
    });
}
);