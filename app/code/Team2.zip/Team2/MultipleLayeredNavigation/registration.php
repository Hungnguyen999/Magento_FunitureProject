<?php
/**
 * Multiple Layered Navigation
 * 
 * @author Slava Yurthev
 */
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'Team2_MultipleLayeredNavigation',
	__DIR__
);